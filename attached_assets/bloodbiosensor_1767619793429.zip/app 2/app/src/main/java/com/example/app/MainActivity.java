package com.example.app;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import org.tensorflow.lite.DataType;
import org.tensorflow.lite.Interpreter;
import org.tensorflow.lite.support.image.TensorImage;
import org.tensorflow.lite.support.tensorbuffer.TensorBuffer;

import java.io.FileInputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;

public class MainActivity extends AppCompatActivity {

    private static final int REQUEST_SELECT_IMAGE = 10;
    private static final int REQUEST_CAPTURE_IMAGE = 12;
    private static final int PERMISSION_REQUEST_CAMERA = 11;

    private Button selectBtn, predictBtn, captureBtn;
    private TextView result;
    private ImageView imageView;
    private Bitmap bitmap;
    private Interpreter tflite;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        try {
            Interpreter.Options options = new Interpreter.Options();
            options.setNumThreads(4); // Set number of threads for inference
            tflite = new Interpreter(loadModelFile(), options);
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Initialize UI elements
        selectBtn = findViewById(R.id.selectBtn);
        predictBtn = findViewById(R.id.predictBtn);
        captureBtn = findViewById(R.id.captureBtn);
        result = findViewById(R.id.result);
        imageView = findViewById(R.id.imageView);

        // Set click listeners
        selectBtn.setOnClickListener(view -> openGallery());
        captureBtn.setOnClickListener(view -> captureImage());
        predictBtn.setOnClickListener(view -> predictImage());

        // Request camera permission if needed
        getPermission();
    }

    private MappedByteBuffer loadModelFile() throws IOException {
        try (FileInputStream fileInputStream = new FileInputStream(getAssets().openFd("best_model.tflite").getFileDescriptor())) {
            FileChannel fileChannel = fileInputStream.getChannel();
            long startOffset = getAssets().openFd("best_model.tflite").getStartOffset();
            long declaredLength = getAssets().openFd("best_model.tflite").getDeclaredLength();
            return fileChannel.map(FileChannel.MapMode.READ_ONLY, startOffset, declaredLength);
        }
    }

    private void openGallery() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("image/*");
        startActivityForResult(intent, REQUEST_SELECT_IMAGE);
    }

    private void captureImage() {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(intent, REQUEST_CAPTURE_IMAGE);
    }

    private void predictImage() {
        if (bitmap == null) {
            result.setText("Please select or capture an image first.");
            return;
        }
        int dimension = 256;
        // Resize the image to 224x224
        Bitmap scaledBitmap = Bitmap.createScaledBitmap(bitmap, dimension, dimension, true);
        // Prepare input buffer
        TensorImage tensorImage = new TensorImage(DataType.FLOAT32);
        tensorImage.load(scaledBitmap);
        // Process the image to create a 1D array of size 100
        float[] inputData = new float[100]; // Array to hold 100 features
        // Example feature extraction: this will depend on your specific model requirements
        // Here, you could flatten the image or extract specific pixel values/features
        // For example, simply averaging over the first 100 pixels (you might need different logic based on your model):
        for (int i = 0; i < 100; i++) {
            // Check if within image bounds
            int pixel = scaledBitmap.getPixel(i % dimension, 0);
            // Get RGB values (normalize if needed)
            float r = (Color.red(pixel) / 255.0f);
            float g = (Color.green(pixel) / 255.0f);
            float b = (Color.blue(pixel) / 255.0f);
            // Use just one channel or a combination for feature (e.g., average)
            inputData[i] = (r + g + b) / 3; // Averaging RGB values (or adjust as per your needs)
        }
        // Prepare input buffer with shape [1, 100]
        TensorBuffer inputBuffer = TensorBuffer.createFixedSize(new int[]{1, 100}, DataType.FLOAT32);
        inputBuffer.loadArray(inputData); // Load your input data into the buffer
        // Prepare output buffer with shape [1, 4]
        TensorBuffer outputBuffer = TensorBuffer.createFixedSize(new int[]{1, 4}, DataType.FLOAT32);
        // Run the interpreter
        tflite.run(inputBuffer.getBuffer(), outputBuffer.getBuffer().rewind());
        // Get prediction result and display it
        result.setText("Prediction: " + getMax(outputBuffer.getFloatArray()));
    }

    private int getMax(float[] arr) {
        int maxIndex = 0;
        for (int i = 1; i < arr.length; i++) {
            if (arr[i] > arr[maxIndex]) maxIndex = i;
        }
        return maxIndex;
    }

    private void getPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
                checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, PERMISSION_REQUEST_CAMERA);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == PERMISSION_REQUEST_CAMERA && grantResults.length > 0 &&
                grantResults[0] != PackageManager.PERMISSION_GRANTED) {
            result.setText("Camera permission is required to use the capture feature.");
        }
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null) return;

        try {
            if (requestCode == REQUEST_SELECT_IMAGE && data.getData() != null) {
                Uri uri = data.getData();
                bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), uri);
            } else if (requestCode == REQUEST_CAPTURE_IMAGE) {
                bitmap = (Bitmap) data.getExtras().get("data");
            }
            imageView.setImageBitmap(bitmap);
        } catch (IOException e) {
            e.printStackTrace();
            result.setText("Failed to load image.");
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (tflite != null) {
            tflite.close();
        }
    }
}